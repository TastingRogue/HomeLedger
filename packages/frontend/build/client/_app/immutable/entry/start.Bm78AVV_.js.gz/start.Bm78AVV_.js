import{l as o,a as r}from"../chunks/K4h_Gg_i.js";export{o as load_css,r as start};
