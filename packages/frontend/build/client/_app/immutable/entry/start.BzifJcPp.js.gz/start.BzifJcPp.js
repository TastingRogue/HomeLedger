import{l as o,a as r}from"../chunks/Tno6ARpe.js";export{o as load_css,r as start};
