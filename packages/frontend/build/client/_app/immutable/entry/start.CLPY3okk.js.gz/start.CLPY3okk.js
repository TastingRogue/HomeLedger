import{l as o,a as r}from"../chunks/BDER4wWl.js";export{o as load_css,r as start};
