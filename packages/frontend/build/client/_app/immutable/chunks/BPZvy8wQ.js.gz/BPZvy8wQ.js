import{b as p,E as t}from"./BJaGh-3h.js";import{B as c}from"./CUBKauz4.js";function E(r,s,...a){var e=new c(r);p(()=>{const n=s()??null;e.ensure(n,n&&(o=>n(o,...a)))},t)}export{E as s};
